#!/bin/bash

#************************************************************************************************************************************************************************************************
#This bash script was written to facilitate the transfer of modEncode data between various servers and was later adapted to be utilized with Amazon cloud services. It contains various functions #that were written/hacked together as the need for them arose. Each function is commented and details should be pretty self explanitory.
#************************************************************************************************************************************************************************************************

#**********************************************************
#This function removes duplicate lines of text from a file
#**********************************************************
function removeDuplicates () {
	echo -e "\nRemoving any duplicates..."
	sort $1 > tempFileList
	uniq tempFileList > $1 
	rm tempFileList
 }


#**************************************************************************************************************************************************************************************************
#Reads files and then gets lines containing the path /browser_data/ cleans those lines up and grabs the file paths assuming that file extentions end with .bam, .bw or .fasta. Initially this was
#used to go through Gbrowse config files and sql dumps of modEncode Gbrowse databases and was used to generate a list of files that were to be copied to the cloud.
#Varibles sent in are: $1 = Name of folder where the config files/sql databases are located in .gz archives $2 = Type of files that are being looked at e.g. .config or .sql
#**************************************************************************************************************************************************************************************************
function copyConfig () {
	for filePath in $(find $1 | grep .gz); do {
		echo -e "\nExtracting" $filePath"..."
		gunzip -c $filePath > ~/temp$2 	
		echo "Reading data from" $filePath"..."
		#Using stream editor and regular expression in perl to get the desired filepath and then writing it out to a file called neededFiles
		grep 'browser_data' ~/temp$2 | sed 's/\,/\n/g' | grep browser | perl -ne '{s!.*/browser!/browser!;print;}' | sed 's!.bw.*!.bw!' | sed 's!.bam.*!.bam!' | sed 's/(//g' | sed 's/)//g' | sed "s/'//g" >> neededFiles	
        	rm temp$2
   	}
   	done
 }

#***************************************************************************************************************************************************************************************************
#This function opens the pathFile created by the helper script parser, goes through it and lists all the files in that path which have a similar of a a similar name. It then writes out all those files with their location to a file called allFiles. 
#***************************************************************************************************************************************************************************************************
function addMissedFiles () {
	while read LINE
	   do 
    		filePath=$LINE
    		read LINE
		fileName=$LINE
		#Assuming that modencode3 is the prefix, may be changed if location of '/modencode/modencode3/browser_data/ changes    		
		for differentFiles in $(ls /modencode3/$filePath | grep $fileName); do 
      			echo $filePath$differentFiles >> allFiles 
      			echo "Writing $filePath$differentFiles"
    		done
	done < pathFile;
 }

#**************************************************************************************************************************************************
#This functions calculates the size of all the files listed in a text file. It also outputs the number of files whose sizes are greater than 500Mb
# $1 - Filename where files are located
# $2 - File path prefix e.g. /modencode/modencode3/
#**************************************************************************************************************************************************
function checkSize () {
	#Calculating the size of all the files
	echo -n "Calculating file sizes: ["
	while read LINE
	do 
        	fileName=$LINE
        	temp=`stat -c %s $2$fileName`
        	size=$(($size+$temp))
        	if [ $temp -ge 524288000 ]; then
            		bigFiles=$(($bigFiles+1))
			#Output the variable thisone to a file if you want to know which files are larger than 500mB            		
			thisone=$2$fileName
		fi
		try=$(($try+1))
        	if [ $try -eq 100 ]; then
            		try=0
            		echo -n "."
        	fi        
	done < $1;
	echo "]"
	#Need to use the bc module to do floating point math	
	totalSize=$(echo "scale=3; $size/1073741824" | bc)
	echo -e "The total size is $totalSize GB."
	echo "The number of files larger than 500Mb are: $bigFiles"
	echo "File larger than 500Mb: $thisone" 
 }

#*****************************************************************************************************************************************************************************************
#This function creates populates the directory structure to be copied. This was used to create a similar directory structure to what was in 'modencode3/modencode/browser_data/" in both
#the /modencode/modencode-dcc machine mounted on xfer-cloud and the Amazon EC2 EBS volumes containing the Fly and Worm data. 
# ARGUMENTS IN
   # $1 Name of file containing paths of all files to be copied
   # $2 Destination path
#*****************************************************************************************************************************************************************************************
function makeDirectoryStructure () {
	#Read and Seperate all directory paths	
	while read LINE
	   do 
		echo `dirname $LINE` >> directoryPaths2
    	done < $1;
	echo "The paths were ascertained...Creating the directory structure now."
	#Removing Duplicates
	removeDuplicates ~/directoryPaths2
	#Creating Directories	
	while read LINE
	   do 
		test -d $2$LINE		
		#Checking if directories already exist 		
		if [ $? -eq 0 ]; then
			echo "Directory $2$LINE already exists!"
		else 
			mkdir -p $2$LINE
	 	fi	  
	done < directoryPaths2;
	
 }

#******************************************************************************
#This function actually copies the files
# Parameters taken in are 
#	$1 = basePath where the files are located
#	$2 = where the files are to be moved
#	$3 = file containing list of filenames to be copied
#******************************************************************************
function copyFiles () {
	while read LINE
	   do 
		test -e $1$LINE	
		#Checking if file exists
		if [ $? -eq 0 ]; then
			echo $1$LINE" ==> "$2$LINE #>>copyLog
			#Checking if the file is larger than 500Mb
			temp=`stat -c %s $1$LINE`
			#Was previously splitting large files into smaller ones, there was no
			#need for that but i kept this option around, e.g copied all large files to
			#one EBS volume and the remaining ones to another drive
			if [ $temp -ge 524288000 ]; then
				echo -e "$1$LINE is greater than 500Mb.\n"
				rsync --sparse $1$LINE $2$LINE
			#If the file is smaller than 500Mb then proceed to copy normally			
			else 	
				rsync --sparse $1$LINE $2$LINE				
			fi
		else 
			echo "File $1$LINE not found." >> errorLog
		fi	
	done < $3;
 }



#*************************************************************************************************************
#This function reads in file paths from a file and outputs the md5sum of the files to a textfile
# $1 = name of file containing filepaths, #2 = where the md5sums are output
#*************************************************************************************************************
function genMD5 () {
	while read LINE
	    do
		test -e $1$LINE
		if [ $? -eq 0 ]; then
			md5sum $1$LINE >> $2
			echo -e "md5sum for $1$LINE generated.\n"
		fi
	done < flyFiles;
 }

#****************************************************************************************************************************
#This function takes in two filenames containing md5Sums, compares them and writes out differences to a file
# $1 & $2 files containing md5sums
#****************************************************************************************************************************
function compareMD5 () {
	
	cat $1 | perl -ne '{s!/.*!!;print;}' > $1SumsOnly
        cat $2 | perl -ne '{s!/.*!!;print;}' > $2SumsOnly
	diff $1SumsOnly $2SumsOnly > sumDiff
	if [[ -s sumDiff ]] ; then
		echo "There were differences in the md5 sums. They have been output to the file sumDiff"
	else
		echo "md5 sums were exactly the same, no differences."
	fi
	rm $1SumsOnly
	rm $2SumsOnly
 }

#******************************************************************************************************************
#This function checks the size of the files copied over. Any differences are output to a text file
# $1 Path to original files, $2 Path to copied files
#******************************************************************************************************************
function compareSize () {
	echo -n "Please wait checking file sizes [."	
	while read LINE
	   do
		originalSize=`stat -c %b $1$LINE`
		copySize=`stat -c %b $2$LINE`
		difference=$(echo "scale=2; $copySize/$originalSize" | bc)
		#If the difference in block numbers is more than 3% then there
		#might have been an error when copying over the files	
		if [ `(echo "scale=2; a=1.00; if (a < $difference) a;" | bc)` ]; then
			difference=$(echo "scale=2; $difference-1" | bc)
		else 
			difference=$(echo "scale=2; 1-$difference" | bc)
		fi
		if [ `(echo "scale=2; a=0.05; if (a < $difference) a;" | bc)` ]; then
			echo "$LINE $originalSize $copySize" >> notEqual
		fi		
		try=$(($try+1))
        	if [ $try -eq 100 ]; then
            		try=0
            		echo -n "."
        	fi 
	done < allFiles;
	echo ".]"
	if [ n `test -e notEqual` ]; then
			echo "All file sizes were equal."
	fi 
 }


#*******************************************************************************************************************************************
#This function makes a list of all the files that were not copied or listed in the config or sql files---- $1 is the original folder under 
#where all the files can be found
#*******************************************************************************************************************************************
function notCopied () {
	#Removes the /modencode3 from the front...	
	find "/"$1"/" | perl -ne '{s!.*browser_data/!/browser_data!;print;}' > everyFile
	for Line in $(cat everyFile); do
		  if [[ -z `grep $Line ~/allFiles` ]]; then	
			echo $Line >> notCopied
		  fi
	done < everyFile;
	echo `wc -l notCopied`" files were not required to be copied. These files are listed in the file called notCopied"
	rm everyFile
  }

##****************************************************************************************************************************************************
#This function opens a file reads the file paths from it and syncs those files onto an amazon instance. This function takes in the following arguments

# [1] The filename where the filepaths are located
# [2] The public DNS or IP of the instance				~/modencode
# [3] The file destination on the instance
# [4] The Location of the keypair required to ssh into the machine
# [5] The basepath "suffix" to add in front of the file paths (locally) /.mounts/sata/bas014/modencode/modencode-dcc/sohaib/staging
# [6] The username on the instance (must have su permissions)
# rsync options explained 
#-Paz (-P = shows progress and does not delete partially transferred files)
#     (-a = recursively transfer everything and preserve eveything)
#     (-z = compression option) 
#--sparse (Handle sparse files efficiently)
#-rsh "ssh  keypair " <- Specifies how to to connect to the instance in this case using ssh and a keypair
#--rsync-path Specifies rsync to be run as sudo on the other end

#******************************************************************************************************************************************************
function syncToInstance () {

	while read LINE
	   do 
		test -e $5$LINE	
		#Checking if file exists
		if [ $? -eq 0 ]; then
			#Checking if the file is larger than 500Mb
			temp=`stat -c %s $5$LINE`
			#Was splitting up the files into smaller parts before but the newer versions of s3fs have this capability built in left this
			#as a condition here to control which files get rsynced
			if [ $temp -ge 1610612736 ]; then
				echo -e "Largefile" $5$LINE "==>" $3$LINE "\n" >> copyLog
				rsync -Paz --sparse --rsh "ssh -i $4" --rsync-path "sudo rsync" $5$LINE $6@$2:$3
			#If the file is smaller than 500Mb then proceed to copy normally			
			else 	
				rsync -Paz -v -v --sparse --rsh "ssh -i $4" --rsync-path "sudo rsync" $5$LINE $6@$2:$3$LINE				
				echo $5$LINE" ==> "$3$LINE >> copyLog
			fi
		else 
			echo "File $5$LINE not found." >> errorLog
		fi	
	done < $1;
	echo "Finished synching files with the cloud"
 }

:<<'END'
#Sample calls have been commented out, towards the end this script was only used to sync files to amazon EBS volumes 
#Left calls here in case modEncode data needs to be updated
#****************************************************************************************************************
#			  CALLS
#****************************************************************************************************************

#Getting the paths of the configuration and sql dumps
echo "Please enter the Path where the config files are: "
#read configFolderPath
configFolderPath="/modencode3/browser_data/conf/"

echo "Please enter the Path where the sql dumps are located: "
#read sqlFolderPath
sqlFolderPath="/modencode3/browser_data/mysql_dumps/"

#########Retreiving file paths from the config files#############
echo $configFolderPath
echo $sqlFolderPath
fileType=".conf"
copyConfig $configFolderPath $fileType
removeDuplicates ~/neededFiles
j=$(echo $k|(wc -l neededFiles | sed 's/\([0-9]*\).*/\1/'))
echo -e "\n"$j" data files are required." 

#########Retreiving files from the sql databases###########
echo -e "\nFinished with the .conf (configuration) files, now extracting data from the sequel (.sql) dumps."
fileType=".sql"
copyConfig $sqlFolderPath $fileType
removeDuplicates ~/neededFiles
j=$(echo $k|(wc -l neededFiles | sed 's/\([0-9]*\).*/\1/'))
echo -e "\n"$j" data files are required."

#Making final pass over all file paths and removing garbage from them
cat neededFiles | perl -ne '{s!\.fasta.*!.fasta!;print;}' |  perl -ne '{s!\.wigdb.*!.wigdb!;print;}' | perl -ne '{s!\.wib.*!.wib!;print;}' | perl -ne '{s!\.wig\\.*!.wig!;print;}' > tempStorage
cat tempStorage > neededFiles
removeDuplicates ~/neededFiles
rm tempStorage

#Since there may be multiple files with the same name and the extensions may be similar, some files may get left out
#parser is a helper script written in perl which goes through the file names written so far and parses the paths and the
#file names and outputs them into a a file called pathFile
./parser
#Adding any files that may have been skipped over 
addMissedFiles


#Starting copying procedure
echo "Please enter the path where you want the data copied: "
dataPath="/modencode/modencode-dcc/sohaib/staging"
#read dataPath
#echo $dataPath
basePath="/modencode3"
#makeDirectoryStructure $dataPath
copyFiles $basePath $dataPath

#Comparing the md5sums of the copied and original files
basePath="/modencode/modencode-dcc/sohaib/staging"
genMD5 $basePath copySums
compareMD5  sums copySums

#Comparing the size of the copied files to the size of the files not copied
compareSize "/modencode3" "/modencode/modencode-dcc/sohaib/staging"
notCopied "/modencode3/browser_data/"

END

#Sample call syncing files from xfer to the modeEncode FTP server
syncToInstance "missingFiles" "ec2-174-129-103-212.compute-1.amazonaws.com" "/modencode/modencode-dcc/drive8/data/" "/u/squreshi/id_sohaib_default" "/.mounts/sata/bas014/modencode/modencode-dcc/data/" "ubuntu"



